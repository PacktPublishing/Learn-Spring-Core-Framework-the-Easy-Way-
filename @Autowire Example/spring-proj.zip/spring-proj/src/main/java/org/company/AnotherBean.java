package org.company;

public class AnotherBean {

	public AnotherBean() {

	}
	
	public void printMessage() {
		System.out.println("From AnotherBean..");
	}

}
