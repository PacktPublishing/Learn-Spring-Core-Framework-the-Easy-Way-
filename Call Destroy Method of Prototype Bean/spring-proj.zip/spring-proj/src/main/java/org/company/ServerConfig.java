package org.company;

import org.springframework.beans.factory.DisposableBean;

public class ServerConfig implements DisposableBean{

	public ServerConfig() {

	}

	public void init() throws Exception {
		System.out.println("ServerConfig : Init called..");

	}

	public void destroy() throws Exception {
		System.out.println("ServerConfig : Destroy called..");

	}

}
