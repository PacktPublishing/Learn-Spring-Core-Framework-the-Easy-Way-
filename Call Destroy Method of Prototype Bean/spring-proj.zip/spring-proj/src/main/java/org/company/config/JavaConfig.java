package org.company.config;

import org.company.PrototypeDestory;
import org.company.ServerConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {
	
	@Bean
	public PrototypeDestory prototypeDestory() {
		return new PrototypeDestory();
	}

	@Bean(initMethod = "init", destroyMethod = "destroy")
	@Scope("prototype")
	public ServerConfig serverConfig() {

		return new ServerConfig();

	}

}
