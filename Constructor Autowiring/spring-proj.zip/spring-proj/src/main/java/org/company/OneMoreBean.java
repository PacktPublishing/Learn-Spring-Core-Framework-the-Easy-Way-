package org.company;

public class OneMoreBean {

	public OneMoreBean() {

	}
	
	public void printMessage() {
		System.out.println("From OneMoreBean..");
	}

}
