package org.company;

public interface Animal {
	
	public void makeNoise();

}
