package org.company;

public class Cat implements Animal{

	public void makeNoise() {
		System.out.println("Meow meow..");
	}

}
