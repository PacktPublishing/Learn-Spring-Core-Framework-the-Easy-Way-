package org.company;

public class Server {

	public Server() {

	}

}
