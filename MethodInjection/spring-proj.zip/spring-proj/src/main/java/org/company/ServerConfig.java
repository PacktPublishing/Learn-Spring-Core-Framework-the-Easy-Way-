package org.company;

public abstract class ServerConfig {

	public ServerConfig() {

	}

	abstract public Server getNewserver();

}
