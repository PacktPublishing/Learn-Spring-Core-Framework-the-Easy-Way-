package org.company;

public class AnotherBean {

	public AnotherBean() {

	}

	public void displayMessage(String message) {
		System.out.println(message);
	}
}
