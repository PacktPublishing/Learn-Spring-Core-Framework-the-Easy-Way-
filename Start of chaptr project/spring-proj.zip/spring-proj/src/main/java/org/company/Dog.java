package org.company;

public class Dog implements Animal{

	public void makeNoise() {
		System.out.println("Bow bow..");	
	}

}
